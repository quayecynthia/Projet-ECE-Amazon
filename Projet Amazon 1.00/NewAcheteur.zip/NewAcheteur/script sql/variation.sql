CREATE TABLE variation(
	Id int(11) NOT NULL AUTO_INCREMENT,
	PRIMARY KEY (Id),
	Sexe varchar (255) NOT NULL,
	Couleur varchar (255) NOT NULL,
	Taille varchar (255) NOT NULL, 
	Type varchar (255) NOT NULL
);